library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library std;

entity i16_addsub_tb is
end entity i16_addsub_tb;

architecture test of i16_addsub_tb is
    signal input_plus   : std_logic_vector(15 downto 0) := (others => '0');
    signal input_minus  : std_logic_vector(15 downto 0) := (others => '0');
    signal output_plus  : std_logic_vector(15 downto 0);
    signal output_minus : std_logic_vector(15 downto 0);
begin
    dut : entity work.i16_addsub_clip
        port map (
            input_plus   => input_plus,
            input_minus  => input_minus,
            output_plus  => output_plus,
            output_minus => output_minus
        );

    stimulus : process
        variable second_input   : integer;
        variable expected_plus  : integer;
        variable expected_minus : integer;
    begin
        for first_input in -32768 to 32767 loop
            second_input := -first_input - 1;
            input_plus  <= std_logic_vector(to_signed(first_input, 16));
            input_minus <= std_logic_vector(to_signed(second_input, 16));
            wait for 1 ns;

            expected_plus := first_input + 1;
            if expected_plus = 32768 then
                expected_plus := -32768;
            end if;
            expected_minus := second_input - 1;
            if expected_minus = -32769 then
                expected_minus := 32767;
            end if;

            assert output_plus = std_logic_vector(to_signed(expected_plus, 16))
                report "PLUS_MISMATCH input=" & integer'image(first_input)
                severity failure;
            assert output_minus = std_logic_vector(to_signed(expected_minus, 16))
                report "MINUS_MISMATCH input=" & integer'image(second_input)
                severity failure;
        end loop;
        -- Check independence when only one input changes.
        input_plus <= x"0000";
        input_minus <= x"0000";
        wait for 1 ns;
        assert output_plus = x"0001" and output_minus = x"FFFF"
            report "ZERO_PAIR_MISMATCH" severity failure;
        input_plus <= x"1234";
        wait for 1 ns;
        assert output_plus = x"1235" and output_minus = x"FFFF"
            report "PLUS_CROSSTALK" severity failure;
        input_minus <= x"FEDC";
        wait for 1 ns;
        assert output_plus = x"1235" and output_minus = x"FEDB"
            report "MINUS_CROSSTALK" severity failure;

        report "I16_ADDSUB_EXHAUSTIVE_PASS values_per_channel=65536 extra_checks=3";
        std.env.finish;
        wait;
    end process;
end architecture test;
