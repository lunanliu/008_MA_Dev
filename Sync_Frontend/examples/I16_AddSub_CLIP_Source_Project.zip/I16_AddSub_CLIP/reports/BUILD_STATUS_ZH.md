# 当前验证状态

按用户最新要求，仅创建Vivado工程，用户自行审阅并手动综合。

- Vivado版本：2021.1。
- 工程创建后重新打开：通过，证据PROJECT_CREATION_PASS.txt。
- 器件：xcvu11p-flgb2104-2-e。
- 硬件顶层：i16_addsub_core；硬件VHDL源文件2个。
- 仿真顶层：i16_addsub_tb；只收录测试台，本次未运行。
- 综合选项：More Options = -mode out_of_context，未启动synth_1。
- 综合线程：PRE钩子general/synth各8；GUI启动时选择16 jobs。
- 实现：未启动impl_1。
- NI官方CLIP XML Schema：通过。
- EDF网表：本次不生成；用户综合后source tools/export_netlist.tcl导出。
- NI编译、时序闭合及板测：未进行。

首次工程配置使用了Vivado2021.1不支持的独立MODE属性，已通过官方MORE OPTIONS属性修正并成功重新打开工程；没有因此运行仿真或综合。原始创建与修复日志保留在work/project_creation，源码和交付包不依赖这些日志。

Vivado提示综合PRE钩子没有加入utils_1，本次整个目录及ZIP均已包含tools/run_threads.tcl，因此本地及整包复制可用。若使用Vivado的Archive Project功能，请一并包含tools目录，不能只取XPR文件。