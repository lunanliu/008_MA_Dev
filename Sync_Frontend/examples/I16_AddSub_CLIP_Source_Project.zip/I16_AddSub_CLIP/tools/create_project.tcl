# Run from Vivado 2021.1: source <project root>/tools/create_project.tcl
# One canonical XPR; no vendor IP, no Python, no external data files.
set root [file normalize [file join [file dirname [info script]] ..]]
set part xcvu11p-flgb2104-2-e
file mkdir [file join $root reports]
file mkdir [file join $root clip]
set xpr [file join $root vivado I16_AddSub I16_AddSub.xpr]
if {[file exists $xpr]} {
    error "Existing XPR preserved. Open it in the GUI; do not blindly rerun the first-build script."
}
source [file join $root tools run_threads.tcl]
create_project I16_AddSub [file dirname $xpr] -part $part
set_property target_language VHDL [current_project]
set_property simulator_language VHDL [current_project]
set_property target_simulator XSim [current_project]
add_files -norecurse [list [file join $root rtl i16_addsub_core.vhd] [file join $root clip i16_addsub_clip.vhd]]
set_property top i16_addsub_core [get_filesets sources_1]
add_files -fileset constrs_1 -norecurse [file join $root constraints i16_addsub_ooc.xdc]
add_files -fileset sim_1 -norecurse [file join $root sim i16_addsub_tb.vhd]
set_property file_type {VHDL 2008} [get_files [file join $root sim i16_addsub_tb.vhd]]
set_property top i16_addsub_tb [get_filesets sim_1]
set_property xsim.elaborate.mt_level 16 [get_filesets sim_1]
set_property xsim.simulate.runtime {70 us} [get_filesets sim_1]
set_property -dict [list {STEPS.SYNTH_DESIGN.ARGS.MORE OPTIONS} {-mode out_of_context}] [get_runs synth_1]
set_property STEPS.SYNTH_DESIGN.TCL.PRE [file join $root tools run_threads.tcl] [get_runs synth_1]
update_compile_order -fileset sources_1
update_compile_order -fileset sim_1
set actual [get_files -of_objects [get_filesets sources_1]]
if {[llength $actual] != 2} {error "Expected exactly two hardware VHDL source files."}
set f [open [file join $root reports actual_sources.txt] w]
foreach source $actual {puts $f [file normalize $source]}
puts $f "PART=[get_property PART [current_project]]"
puts $f "TOP=[get_property TOP [get_filesets sources_1]]"
close $f

puts "I16_ADDSUB_PROJECT_CREATED_NO_SIMULATION_NO_SYNTHESIS"
close_project
