set_param general.maxThreads 8
set_param synth.maxThreads 8
puts "I16_THREADS general=[get_param general.maxThreads] synth=[get_param synth.maxThreads]"
