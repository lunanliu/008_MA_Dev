# Manual step AFTER the user completes synth_1 in the project GUI.
# This script does not launch synthesis, simulation or implementation.
set root [file normalize [file join [file dirname [info script]] ..]]
if {[llength [get_projects -quiet]] != 1} {error "Open I16_AddSub.xpr first."}
if {[get_property PART [current_project]] ne "xcvu11p-flgb2104-2-e"} {error "Wrong FPGA part."}
if {[get_property TOP [get_filesets sources_1]] ne "i16_addsub_core"} {error "Wrong hardware top."}
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {error "Complete Run Synthesis in the GUI first."}
open_run synth_1
if {[llength [get_cells -hier -filter {IS_BLACKBOX == 1}]] != 0} {error "Unresolved black box."}
if {[llength [get_cells -hier -filter {REF_NAME =~ IBUF* || REF_NAME =~ OBUF* || REF_NAME =~ IOBUF*}]] != 0} {
    error "Unexpected physical IO buffers in CLIP core."
}
file mkdir [file join $root reports]
write_edif -force [file join $root clip i16_addsub_core.edf]
report_utilization -file [file join $root reports utilization_synth.rpt]
report_timing_summary -file [file join $root reports timing_synth.rpt]
puts "I16_ADDSUB_EDIF_EXPORTED [file join $root clip i16_addsub_core.edf]"
