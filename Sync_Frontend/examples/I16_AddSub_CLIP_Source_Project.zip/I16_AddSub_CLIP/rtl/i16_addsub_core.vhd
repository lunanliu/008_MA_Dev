library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

-- Two independent signed 16-bit channels.
-- Results wrap modulo 2**16; this is not saturating arithmetic.
entity i16_addsub_core is
    port (
        input_plus  : in  std_logic_vector(15 downto 0);
        input_minus : in  std_logic_vector(15 downto 0);
        output_plus : out std_logic_vector(15 downto 0);
        output_minus: out std_logic_vector(15 downto 0)
    );
end entity i16_addsub_core;

architecture rtl of i16_addsub_core is
begin
    output_plus  <= std_logic_vector(signed(input_plus) + to_signed(1, 16));
    output_minus <= std_logic_vector(signed(input_minus) - to_signed(1, 16));
end architecture rtl;
