# Standalone combinational delay budget only.
# Final LabVIEW timing is constrained and checked by the NI compilation flow.
set_max_delay 8.000 -datapath_only -from [all_inputs] -to [all_outputs]
