# 双通道 I16 加减一 CLIP

一路 input_plus 加1得到 output_plus；另一路 input_minus 减1得到 output_minus。两路相互独立，均为16位有符号二进制补码。全部设计与测试台使用VHDL，不依赖厂商算术IP。

| 同时输入两路的值 | output_plus | output_minus |
|---:|---:|---:|
| 0 | 1 | -1 |
| 100 | 101 | 99 |
| -100 | -99 | -101 |
| 32767 | -32768 | 32766 |
| -32768 | -32767 | 32767 |

溢出按16位回绕，不做饱和截断。纯组合逻辑，无时钟、复位、有效信号或内部流水线；输出在组合传播延迟后稳定。LabVIEW的I/O同步或执行调度可能添加拍数，不能把一次框图写入后立即读取当成零延迟保证。

## 在 LabVIEW FPGA 中导入

1. 将交付的整个 clip 文件夹复制到开发机的本地磁盘。不要只取EDF文件。
2. 打开PXIe-7903的LabVIEW FPGA工程，在FPGA Target的属性中找到Component-Level IP/CLIP配置，添加clip/I16_AddSub.xml定义，并添加一个用户CLIP实例。不同NI版本的菜单位置可能不同。
3. 如果用CLIP向导重新生成定义，选 i16_addsub_clip.vhd 为顶层文件、i16_addsub_clip / structural 为实体/架构，并将 i16_addsub_core.edf 加入实现文件。所有四个端口映射I16；本模块没有时钟端口。
4. 两个输入是 input_plus、input_minus；两个输出是 output_plus、output_minus。建议放在同一SCTL时钟域中读写，避免跨域直接连接。本模块不包含跨时钟域电路。
5. 初次硬件检查先输入固定值0、100、-100和边界值，等待数据稳定后读回并对照上表。之后再做连续变化输入，并按LabVIEW实际I/O同步延迟对应输入与输出。
6. 由LabVIEW完成FPGA全工程编译并部署。这份EDF是用户逻辑子网表，不是可直接下载的整片FPGA bitfile。

XML已按本机LabVIEW2026官方CLIPDeclaration.xsd核查；仍需用户在实际Target中导入并编译验证。XML将实现文件排除于LabVIEW主机仿真模型，不提供LabVIEW桌面仿真模型；独立行为验证使用Vivado测试台。

## 文件导航

| 路径 | 内容 |
|---|---|
| rtl/i16_addsub_core.vhd | 可阅读、修改的算术核心源码 |
| clip/i16_addsub_clip.vhd | LabVIEW端口封装；用component实例化EDF核心 |
| clip/i16_addsub_core.edf | 本次不生成；由用户完成综合后手动导出 |
| clip/I16_AddSub.xml | 四个I16端口的CLIP定义；三个文件放在同一目录 |
| vivado/I16_AddSub/I16_AddSub.xpr | Vivado 2021.1工程，双击即可打开 |
| sim/i16_addsub_tb.vhd | 每路65536种输入及3次通道独立性检查 |
| constraints/i16_addsub_ooc.xdc | 单独核心8ns组合路径预算，不是外部时钟要求 |
| tools/create_project.tcl | 只创建工程，不运行仿真或综合 |
| tools/run_threads.tcl | Vivado父进程及综合子进程的8线程设置 |
| reports/ | 源文件指纹、实际选源、仿真与综合证据 |

GUI中hardware top是 i16_addsub_core，simulation top是 i16_addsub_tb，测试台经过 i16_addsub_clip 封装验证核心。CLIP顶层不参与单独核心综合网表导出，它在LabVIEW集成时与EDF一起链接。所有使用的文件显式加入sources_1/sim_1，不扫描其他工程历史版本。

## 现在由用户在GUI审阅与综合

1. 双击 vivado/I16_AddSub/I16_AddSub.xpr。器件已设置为xcvu11p-flgb2104-2-e。
2. Sources的Design Sources中，i16_addsub_core为综合顶层。打开该VHDL，核心仅有两条加减运算语句。i16_addsub_clip是单独的LabVIEW端口封装；它不作为核心综合网表的综合顶层。
3. 如需审阅测试台，查看Simulation Sources中的i16_addsub_tb。本次未运行任何仿真，用户可自行选择是否执行。
4. 点击Run Synthesis，在Launch Runs选16 jobs。工程已设置Out-of-Context模式，综合PRE脚本会将general/synth线程设置为8。无需Run Implementation。
5. 综合完成后，在该工程的Tcl Console执行下面命令，导出EDF及资源/时序报告；该脚本不会重新综合：

    source D:/008_MA_Dev/I16_AddSub_CLIP/tools/export_netlist.tcl

6. 确认clip目录新增i16_addsub_core.edf，之后再按前述流程导入LabVIEW。现在XML只通过格式校验，尚不能作为包含完整网表的交付包导入编译。

如移动了工程目录，将上面命令路径改成新目录即可。create_project.tcl只用于首次创建，遇到已有XPR时拒绝覆盖；日常开发直接用GUI打开XPR。

本核独立综合与网表回读不等同于LabVIEW最终布局布线通过；真正的SCTL频率和跨模块路径由NI全工程编译检查。本模块不要求新增MMCM、PLL或参考时钟。

## NI 官方说明

- [VHDL封装及Vivado综合网表集成](https://knowledge.ni.com/KnowledgeArticleDetails?id=kA03q000000x4G6CAI&l=en-US)
- [CLIP端口类型与导入](https://knowledge.ni.com/KnowledgeArticleDetails?id=kA03q000000x0jiCAA&l=en-US)

## 验证状态

见 reports/BUILD_STATUS_ZH.md。按用户最新要求，仅创建工程；没有运行行为仿真、综合、实现，也没有生成EDF网表。NI XML格式校验通过不等于网表交付或硬件通过。
