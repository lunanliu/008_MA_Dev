library ieee;
use ieee.std_logic_1164.all;

-- LabVIEW CLIP entry point.
-- Add this VHDL file and i16_addsub_core.edf to the CLIP definition.
entity i16_addsub_clip is
    port (
        input_plus   : in  std_logic_vector(15 downto 0);
        input_minus  : in  std_logic_vector(15 downto 0);
        output_plus  : out std_logic_vector(15 downto 0);
        output_minus : out std_logic_vector(15 downto 0)
    );
end entity i16_addsub_clip;

architecture structural of i16_addsub_clip is
    component i16_addsub_core is
        port (
            input_plus   : in  std_logic_vector(15 downto 0);
            input_minus  : in  std_logic_vector(15 downto 0);
            output_plus  : out std_logic_vector(15 downto 0);
            output_minus : out std_logic_vector(15 downto 0)
        );
    end component;
begin
    arithmetic_core : i16_addsub_core
        port map (
            input_plus   => input_plus,
            input_minus  => input_minus,
            output_plus  => output_plus,
            output_minus => output_minus
        );
end architecture structural;
