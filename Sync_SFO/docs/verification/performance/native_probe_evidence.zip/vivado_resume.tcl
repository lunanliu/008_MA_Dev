# Resume only the unexecuted native child runs; preserve earlier parameter results.
set root [file normalize [file dirname [info script]]]
set started [clock seconds]
open_project [file join $root scratch tiny_probe.xpr]
source [file join $root selected_threads.tcl]
set_param general.maxThreads 8
set_param synth.maxThreads $probe_synth_threads
if {[get_property PROGRESS [get_runs synth_1]] ne "0%"} {error "Synthesis already progressed; do not repeat"}
# OOC avoids unrelated board pin assignments; this is still a native project run.
set_property -name {STEPS.SYNTH_DESIGN.ARGS.MORE OPTIONS} -value {-mode out_of_context} -objects [get_runs synth_1]
set_property STEPS.SYNTH_DESIGN.TCL.PRE [file join $root child_hook.tcl] [get_runs synth_1]
foreach step {OPT_DESIGN PLACE_DESIGN ROUTE_DESIGN} {
    set_property STEPS.${step}.TCL.PRE [file join $root child_hook.tcl] [get_runs impl_1]
}
launch_runs synth_1 -jobs 1
wait_on_run synth_1
set f [open [file join $root native_stage_results.txt] w]
puts $f [list SYNTH [get_property STATUS [get_runs synth_1]] elapsed_seconds [expr {[clock seconds]-$started}]]
flush $f
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {close $f;error "Tiny synthesis did not complete"}
if {[clock seconds]-$started < 67} {
    launch_runs impl_1 -to_step route_design -jobs 1
    wait_on_run impl_1
    puts $f [list IMPLEMENTATION [get_property STATUS [get_runs impl_1]] elapsed_seconds [expr {[clock seconds]-$started}]]
} else {
    puts $f "IMPLEMENTATION_SKIPPED: insufficient remaining bounded budget"
}
close $f
close_project
puts "PERFORMANCE_PROBE_NATIVE_END"
exit 0
