$Stage='vivado_finish_rev04'
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$freeze=Get-Content -LiteralPath (Join-Path $root ($Stage+'_design.json')) -Raw|ConvertFrom-Json
$execution=Get-Content -LiteralPath (Join-Path $root ($Stage+'_execution.json')) -Raw|ConvertFrom-Json
if((Get-FileHash -LiteralPath (Join-Path $root ($Stage+'_design.json'))).Hash -ne $execution.design_sha256){throw 'Design freeze changed'}
foreach($item in @($freeze.inputs)+@($execution.inputs)){
 if((Get-FileHash -LiteralPath (Join-Path $root $item.name)).Hash -ne $item.sha256){throw ('Input changed: '+$item.name)}
}
Add-Type -Path (Join-Path $root 'probe_job.cs')
$stages=if($Stage -eq 'all'){@('vivado','matlab')}else{@($Stage)}
foreach($name in $stages){
 $spec=$freeze.stages.$name
 $resultPath=Join-Path $root ($name+'_owned_exit.json')
 if(Test-Path -LiteralPath $resultPath){throw ('Stage already attempted; preserve it: '+$name)}
 if($name -eq 'vivado' -and (Test-Path -LiteralPath (Join-Path $root 'vivado.log'))){throw 'Existing Vivado evidence; do not repeat'}
 if($name -eq 'matlab' -and (Test-Path -LiteralPath (Join-Path $root 'matlab.log'))){throw 'Existing MATLAB evidence; do not repeat'}
 $native=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -match '^(MATLAB|vivado|rdiArgs|xsim|xsimk|xelab|xvlog|xvhdl)\.exe$'}|Select-Object Name,ProcessId,CreationDate,CommandLine)
 foreach($p in $native){if($p.Name -ne 'vivado.exe' -or $p.ProcessId -ne 32816){throw 'Another native task exists; do not touch it'}}
 $freeGiB=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB
 if($freeGiB -lt 6){throw 'Less than 6 GiB free RAM'}
 $command=$execution.commands.$name
 $oldPref=$env:MATLAB_PREFDIR
 if($name -eq 'matlab'){$env:MATLAB_PREFDIR=$spec.private_environment.MATLAB_PREFDIR;[void][IO.Directory]::CreateDirectory($env:MATLAB_PREFDIR)}
 [ordered]@{stage=$name;utc=[DateTime]::UtcNow.ToString('o');command=$command;free_gib=$freeGiB;inventory=$native;hard_timeout_s=$spec.hard_timeout_seconds;memory_gib=$spec.owned_memory_gib}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $root ($name+'_launch.json')) -Encoding utf8
 $owned=$null;$watch=[Diagnostics.Stopwatch]::StartNew();$reason=$null;$errorText=$null;$lastLog=-5;$finalActive=-1;$returnCode=$null;$rootExited=$false;$peak=0L;$lowMemoryAt=$null;$softExceeded=$false;$minimumAvailableGiB=999.0
 try{
  $owned=[NativeProjectJob]::new($command,$root)
  while($true){
   $active=$owned.Active();$rootExited=$owned.RootExited();$bytes=0L;$privateBytes=0L;$members=@()
   foreach($memberId in $owned.Pids()){try{$p=Get-Process -Id $memberId -ErrorAction Stop;$bytes+=$p.WorkingSet64;$privateBytes+=$p.PrivateMemorySize64;$members+=@{pid=$memberId;name=$p.ProcessName;working_set=$p.WorkingSet64;private_committed=$p.PrivateMemorySize64}}catch{}}
   $peak=[Math]::Max($peak,$bytes)
   $availableGiB=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB
   $minimumAvailableGiB=[Math]::Min($minimumAvailableGiB,$availableGiB)
   if($watch.Elapsed.TotalSeconds-$lastLog -ge 5){
    [ordered]@{utc=[DateTime]::UtcNow.ToString('o');elapsed_s=$watch.Elapsed.TotalSeconds;active=$active;root_exited=$rootExited;working_set=$bytes;private_committed=$privateBytes;system_available_gib=$availableGiB;soft_4gib_crossed=$softExceeded;members=$members}|ConvertTo-Json -Depth 4 -Compress|Add-Content -LiteralPath (Join-Path $root ($name+'_processes.jsonl')) -Encoding utf8
    $lastLog=$watch.Elapsed.TotalSeconds
   }
   if($active -eq 0 -and $rootExited){break}
   if($watch.Elapsed.TotalSeconds -ge [int]$spec.hard_timeout_seconds){$reason='hard_timeout';$owned.Stop(124);break}
   if($bytes -gt 4GB -and -not $softExceeded){$softExceeded=$true;Write-Output 'Memory soft alert: summed working sets above 4 GiB; computation continues'}
   if($availableGiB -lt 2){
    if($null -eq $lowMemoryAt){$lowMemoryAt=$watch.Elapsed.TotalSeconds}
    if($watch.Elapsed.TotalSeconds-$lowMemoryAt -ge 10){$reason='system_available_below2GiB_for10s';$owned.Stop(125);break}
   }else{$lowMemoryAt=$null}
   Start-Sleep -Milliseconds 500
  }
 }catch{$errorText=$_.ToString();if($null -ne $owned){$owned.Stop(126)}}finally{
  if($null -ne $owned){
   $drain=[Diagnostics.Stopwatch]::StartNew()
   while($drain.Elapsed.TotalSeconds -lt 10){$finalActive=$owned.Active();$rootExited=$owned.RootExited();if($finalActive -eq 0 -and $rootExited){$returnCode=$owned.RootCode();break};Start-Sleep -Milliseconds 100}
   $record=[ordered]@{stage=$name;utc=[DateTime]::UtcNow.ToString('o');root_pid=$owned.RootPid;root_returncode=$returnCode;root_exited=$rootExited;owned_active_after=$finalActive;elapsed_s=$watch.Elapsed.TotalSeconds;peak_working_set=$peak;minimum_system_available_gib=$minimumAvailableGiB;soft_4gib_crossed=$softExceeded;stop_reason=$reason;error=$errorText;foreign_pid_modified=$false}
   $record|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $resultPath -Encoding utf8
   $owned.Dispose()
  }
  if($name -eq 'matlab'){$env:MATLAB_PREFDIR=$oldPref}
 }
 if($errorText){
  if(-not (Test-Path -LiteralPath $resultPath)){@{stage=$name;error=$errorText;native_root_constructed=($null -ne $owned);utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $resultPath -Encoding utf8}
  throw $errorText
 }
 if($finalActive -ne 0 -or -not $rootExited){throw 'Owned tree exit not established; stop before next stage'}
 Write-Output ($name+' returned '+$returnCode+'; owned tree empty; elapsed '+$watch.Elapsed.TotalSeconds)
 # A native failure in one independent configuration query does not rerun it.
 # The next tool may run only after this entire owned group has exited.
}
