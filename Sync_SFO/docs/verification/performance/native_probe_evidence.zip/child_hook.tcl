# Executed inside the native child run, not merely in the launcher process.
set probe_root [file normalize [file dirname [info script]]]
source [file join $probe_root selected_threads.tcl]
set before_general [get_param general.maxThreads]
set before_synth [get_param synth.maxThreads]
set_param general.maxThreads 8
set_param synth.maxThreads $probe_synth_threads
set line [list PERF_CHILD_HOOK cwd [pwd] before_general $before_general before_synth $before_synth after_general [get_param general.maxThreads] after_synth [get_param synth.maxThreads]]
puts $line
set f [open [file join [pwd] performance_hook.txt] a]
puts $f $line
close $f
