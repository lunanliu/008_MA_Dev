set probe_synth_threads 8
