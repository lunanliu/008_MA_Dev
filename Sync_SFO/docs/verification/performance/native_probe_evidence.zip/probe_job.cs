using System;using System.Runtime.InteropServices;using System.Text;
public sealed class NativeProjectJob:IDisposable {
 [StructLayout(LayoutKind.Sequential)]struct SI {public uint cb;public IntPtr a,b,c;public uint d,e,f,g,h,i,j,k;public ushort l,m;public IntPtr n,o,p,q;}
 [StructLayout(LayoutKind.Sequential)]struct PI {public IntPtr p,t;public uint pid,tid;}
 [StructLayout(LayoutKind.Sequential)]struct BASIC {public long a,b;public uint flags;public UIntPtr min,max;public uint limit;public UIntPtr affinity;public uint priority,schedule;}
 [StructLayout(LayoutKind.Sequential)]struct IO {public ulong a,b,c,d,e,f;}
 [StructLayout(LayoutKind.Sequential)]struct EXT {public BASIC basic;public IO io;public UIntPtr processMemory,jobMemory,peakProcess,peakJob;}
 [StructLayout(LayoutKind.Sequential)]struct ACCOUNT {public long a,b,c,d;public uint faults,total,active,terminated;}
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateJobObject(IntPtr a,string b);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetInformationJobObject(IntPtr a,int b,ref EXT c,uint d);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool QueryInformationJobObject(IntPtr a,int b,IntPtr c,uint d,out uint e);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool CreateProcess(string a,StringBuilder b,IntPtr c,IntPtr d,bool e,uint f,IntPtr g,string h,ref SI i,out PI j);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool AssignProcessToJobObject(IntPtr a,IntPtr b);
 [DllImport("kernel32.dll")]static extern uint ResumeThread(IntPtr a);
 [DllImport("kernel32.dll")]static extern uint WaitForSingleObject(IntPtr a,uint b);
 [DllImport("kernel32.dll")]static extern bool GetExitCodeProcess(IntPtr a,out uint b);
 [DllImport("kernel32.dll")]static extern bool TerminateJobObject(IntPtr a,uint b);
 [DllImport("kernel32.dll")]static extern bool TerminateProcess(IntPtr a,uint b);
 [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr a);
 IntPtr job,process,thread;public uint RootPid;
 static Exception Error(string s){return new Exception(s+" WinError="+Marshal.GetLastWin32Error());}
 public NativeProjectJob(string cmd,string cwd){
  job=CreateJobObject(IntPtr.Zero,null);if(job==IntPtr.Zero)throw Error("CreateJob");
  EXT limit=new EXT();limit.basic.flags=0x2000;
  if(!SetInformationJobObject(job,9,ref limit,(uint)Marshal.SizeOf(typeof(EXT)))){CloseHandle(job);job=IntPtr.Zero;throw Error("SetJobLimits");}
  SI si=new SI();si.cb=(uint)Marshal.SizeOf(typeof(SI));PI pi;
  if(!CreateProcess(null,new StringBuilder(cmd),IntPtr.Zero,IntPtr.Zero,false,0x08000004,IntPtr.Zero,cwd,ref si,out pi)){CloseHandle(job);job=IntPtr.Zero;throw Error("CreateSuspended");}
  process=pi.p;thread=pi.t;RootPid=pi.pid;
  if(!AssignProcessToJobObject(job,process)){TerminateProcess(process,126);Dispose();throw Error("AssignJob");}
  if(ResumeThread(thread)==0xffffffff){TerminateJobObject(job,126);Dispose();throw Error("Resume");}
 }
 public int Active(){int size=Marshal.SizeOf(typeof(ACCOUNT));IntPtr p=Marshal.AllocHGlobal(size);try{uint n;if(!QueryInformationJobObject(job,1,p,(uint)size,out n))throw Error("QueryActive");return (int)((ACCOUNT)Marshal.PtrToStructure(p,typeof(ACCOUNT))).active;}finally{Marshal.FreeHGlobal(p);}}
 public long[] Pids(){int size=8+256*IntPtr.Size;IntPtr p=Marshal.AllocHGlobal(size);try{uint n;if(!QueryInformationJobObject(job,3,p,(uint)size,out n))throw Error("QueryPids");int count=Marshal.ReadInt32(p,4);if(count>256)throw new Exception("Too many owned processes");long[] ids=new long[count];for(int i=0;i<count;i++)ids[i]=Marshal.ReadIntPtr(p,8+i*IntPtr.Size).ToInt64();return ids;}finally{Marshal.FreeHGlobal(p);}}
 public bool RootExited(){return WaitForSingleObject(process,0)==0;}
 public int RootCode(){uint c;if(!GetExitCodeProcess(process,out c))throw Error("ExitCode");return unchecked((int)c);}
 public void Stop(uint code){if(!TerminateJobObject(job,code))throw Error("TerminateOwnedJob");}
 public void Dispose(){if(thread!=IntPtr.Zero){CloseHandle(thread);thread=IntPtr.Zero;}if(process!=IntPtr.Zero){CloseHandle(process);process=IntPtr.Zero;}if(job!=IntPtr.Zero){CloseHandle(job);job=IntPtr.Zero;}}
}
