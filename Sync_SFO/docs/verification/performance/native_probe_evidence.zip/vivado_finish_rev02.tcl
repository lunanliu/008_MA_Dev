# Same tiny circuit, resumed from its successful opt checkpoint in Non-Project mode.
# The original .xpr and interrupted impl_1 bookkeeping are preserved.
set root [file normalize [file dirname [info script]]]
set rc [catch {
    foreach cmd {open_checkpoint place_design route_design write_checkpoint report_route_status} {
        puts "NATIVE_HELP_BEGIN $cmd"
        help $cmd
        puts "NATIVE_HELP_END $cmd"
    }
    foreach name {tiny_placed_continue.dcp tiny_routed_continue.dcp finish_result.txt} {
        if {[file exists [file join $root $name]]} {error "Preserve existing result, do not repeat: $name"}
    }
    set_param general.maxThreads 8
    set_param synth.maxThreads 8
    set checkpoint [file join $root scratch tiny_probe.runs impl_1 tiny_opt.dcp]
    open_checkpoint $checkpoint
    set part [get_property PART [current_design]]
    set design [get_property NAME [current_design]]
    if {$part ne "xcvu11p-flgb2104-2-e" || $design ne "tiny"} {error "Unexpected checkpoint identity: $part / $design"}
    set f [open [file join $root finish_stage_events.txt] a]
    puts $f [list OPEN_OPT_CHECKPOINT [clock seconds] $checkpoint $part $design]
    flush $f
    source [file join $root child_hook.tcl]
    puts "CONTINUE_PLACE_BEGIN";flush stdout
    place_design
    puts $f [list PLACE_COMPLETE [clock seconds]];flush $f
    write_checkpoint [file join $root tiny_placed_continue.dcp]
    source [file join $root child_hook.tcl]
    puts "CONTINUE_ROUTE_BEGIN";flush stdout
    route_design
    puts $f [list ROUTE_COMPLETE [clock seconds]];flush $f
    write_checkpoint [file join $root tiny_routed_continue.dcp]
    report_route_status -file [file join $root tiny_route_status.rpt]
    report_timing_summary -file [file join $root tiny_routed_timing.rpt]
    report_utilization -file [file join $root tiny_routed_utilization.rpt]
    report_drc -file [file join $root tiny_routed_drc.rpt]
    puts $f [list REPORTS_COMPLETE [clock seconds]]
    close $f
    set f [open [file join $root finish_result.txt] w]
    puts $f [list status NATIVE_COMPLETE_PENDING_REVIEW mode CHECKPOINT_NON_PROJECT part $part top $design general_threads [get_param general.maxThreads] synth_threads [get_param synth.maxThreads] original_impl_run_completed false]
    close $f
    close_design
} message options]
if {$rc} {
    set f [open [file join $root finish_error.txt] w]
    puts $f $message
    if {[dict exists $options -errorinfo]} {puts $f [dict get $options -errorinfo]}
    close $f
    puts stderr $message
    exit 1
}
puts "PERFORMANCE_PROBE_FINISH_NATIVE_END"
exit 0
