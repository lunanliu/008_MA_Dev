# One bounded scratch project; no production input, IP or user project is opened.
set root [file normalize [file dirname [info script]]]
set started [clock seconds]
if {[version -short] ne "2021.1"} {error "Vivado 2021.1 required"}
set f [open [file join $root parameter_probe.txt] w]
puts $f [list version [version -short] general_default [get_param general.maxThreads] synth_default [get_param synth.maxThreads]]
flush $f
set_param general.maxThreads 8
set code [catch {set_param general.maxThreads 9} message]
puts $f [list general_9_probe_code $code message $message]
set_param general.maxThreads 8
set selected 0
foreach value {8 5 4} {
    set code [catch {set_param synth.maxThreads $value} message]
    puts $f [list synth_candidate $value code $code message $message readback [get_param synth.maxThreads]]
    if {!$code && $selected == 0} {set selected $value}
}
if {$selected == 0} {close $f;error "No reviewed synthesis setting accepted"}
set_param synth.maxThreads $selected
puts $f [list selected_general [get_param general.maxThreads] selected_synth [get_param synth.maxThreads]]
close $f
set f [open [file join $root selected_threads.tcl] w]
puts $f [list set probe_synth_threads $selected]
close $f
create_project tiny_probe [file join $root scratch] -part xcvu11p-flgb2104-2-e
add_files -norecurse [file join $root tiny.sv]
add_files -fileset constrs_1 -norecurse [file join $root tiny.xdc]
set_property top tiny [get_filesets sources_1]
# OOC avoids unrelated board pin assignments; this is still a native project run.
set_property {STEPS.SYNTH_DESIGN.ARGS.MORE OPTIONS} {-mode out_of_context} [get_runs synth_1]
set_property STEPS.SYNTH_DESIGN.TCL.PRE [file join $root child_hook.tcl] [get_runs synth_1]
foreach step {OPT_DESIGN PLACE_DESIGN ROUTE_DESIGN} {
    set_property STEPS.${step}.TCL.PRE [file join $root child_hook.tcl] [get_runs impl_1]
}
launch_runs synth_1 -jobs 1
wait_on_run synth_1
set f [open [file join $root native_stage_results.txt] w]
puts $f [list SYNTH [get_property STATUS [get_runs synth_1]] elapsed_seconds [expr {[clock seconds]-$started}]]
flush $f
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {close $f;error "Tiny synthesis did not complete"}
if {[clock seconds]-$started < 80} {
    launch_runs impl_1 -to_step route_design -jobs 1
    wait_on_run impl_1
    puts $f [list IMPLEMENTATION [get_property STATUS [get_runs impl_1]] elapsed_seconds [expr {[clock seconds]-$started}]]
} else {
    puts $f "IMPLEMENTATION_SKIPPED: insufficient remaining bounded budget"
}
close $f
close_project
puts "PERFORMANCE_PROBE_NATIVE_END"
exit 0
