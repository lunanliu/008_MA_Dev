module tiny(input wire clk, input wire rst, output wire [7:0] value);
  reg [7:0] count = 8'd0;
  always @(posedge clk) begin
    if (rst) count <= 8'd0;
    else count <= count + 8'd1;
  end
  assign value = count;
endmodule
