# Read the installed Vivado command help; no project or design is changed.
set root [file normalize [file dirname [info script]]]
foreach cmd {launch_runs reset_runs open_run open_checkpoint place_design route_design write_checkpoint report_route_status} {
    redirect -file [file join $root help_${cmd}.txt] [list help $cmd]
}
puts "PERFORMANCE_PROBE_HELP_COMPLETE"
exit 0
