# Same tiny circuit, resumed from the successful opt checkpoint in Non-Project mode.
# Rev04 fixes only the Tcl channel collision from child_hook.tcl; prior evidence stays intact.
set root [file normalize [file dirname [info script]]]
set rc [catch {
    foreach cmd {open_checkpoint place_design route_design write_checkpoint report_route_status} {
        puts "NATIVE_HELP_BEGIN $cmd"
        help $cmd
        puts "NATIVE_HELP_END $cmd"
    }
    set checkpoint [file join $root scratch tiny_probe.runs impl_1 tiny_opt.dcp]
    open_checkpoint $checkpoint
    set part [get_property PART [current_design]]
    set design [get_property NAME [current_design]]
    if {$part ne "xcvu11p-flgb2104-2-e" || ($design ne "tiny" && $design ne "checkpoint_tiny_opt")} {
        error "Unexpected checkpoint identity: $part / $design"
    }
    foreach name {tiny_placed_continue_rev04.dcp tiny_routed_continue_rev04.dcp finish_result_rev04.txt} {
        if {[file exists [file join $root $name]]} {error "Preserve existing result, do not repeat: $name"}
    }
    set event_chan [open [file join $root finish_stage_events_rev04.txt] a]
    puts $event_chan [list OPEN_OPT_CHECKPOINT [clock seconds] $checkpoint $part $design]
    flush $event_chan
    source [file join $root child_hook.tcl]
    puts "CONTINUE_PLACE_BEGIN"
    flush stdout
    place_design
    puts $event_chan [list PLACE_COMPLETE [clock seconds]]
    flush $event_chan
    write_checkpoint [file join $root tiny_placed_continue_rev04.dcp]
    source [file join $root child_hook.tcl]
    puts "CONTINUE_ROUTE_BEGIN"
    flush stdout
    route_design
    puts $event_chan [list ROUTE_COMPLETE [clock seconds]]
    flush $event_chan
    write_checkpoint [file join $root tiny_routed_continue_rev04.dcp]
    report_route_status -file [file join $root tiny_route_status_rev04.rpt]
    report_timing_summary -file [file join $root tiny_routed_timing_rev04.rpt]
    report_utilization -file [file join $root tiny_routed_utilization_rev04.rpt]
    report_drc -file [file join $root tiny_routed_drc_rev04.rpt]
    puts $event_chan [list REPORTS_COMPLETE [clock seconds]]
    close $event_chan
    set result_chan [open [file join $root finish_result_rev04.txt] w]
    puts $result_chan [list status NATIVE_COMPLETE_PENDING_REVIEW mode CHECKPOINT_NON_PROJECT part $part loaded_design_name $design logical_top tiny general_threads [get_param general.maxThreads] synth_threads [get_param synth.maxThreads] original_impl_run_completed false]
    close $result_chan
    close_design
} message options]
if {$rc} {
    set error_chan [open [file join $root finish_error_rev04.txt] w]
    puts $error_chan $message
    if {[dict exists $options -errorinfo]} {puts $error_chan [dict get $options -errorinfo]}
    close $error_chan
    puts stderr $message
    exit 1
}
puts "PERFORMANCE_PROBE_FINISH_NATIVE_END"
exit 0